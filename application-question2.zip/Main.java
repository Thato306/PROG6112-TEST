import java.util.Scanner;

public interface IConsoles { 
    String getConsoletype();
    String getStore();
    int getTotalSales();
}

abstract class Console implements IConsoles {
    private String consoleType;
    private String store;
    private int totalSales;
    
    public Console(String consoleType, String store, int totalSales) 
        this.consoleType = consoleType;
        this.store= store;
        this.totalSales = totalSales;
}
    public String getConsoletype() {
        return consoleType;
    }
    
    public  String getStore() {
        return store;
    }
    
    public int getTotalSales() {
        return totalSales;
    }
}

class ConsoleSales extends Console {
    public ConsoleSales(String consoleType, String store, int totalSales) {
        super(consoleType, store, totalSales);
    }
    
    public void printReport() {
        System.out.println("Console Type: " + getConsoletype());
        System.out.println("Store Name: " + getStore());
    }
}

public class RunApplication {
        
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter console type: ");
            String consoleType = input.nextLine();
        
        System.out.print("Enter store name: ");
        String store = input.nextLine();
        
        System.out.print("Enter total amount of sales: ");
            int totalSales = input.nextInt();
            
        ConsoleSales console = new ConsoleSales(
            consoleType,
            store,
            totalSales);
            
            console.printReport();
            
            input.close();
    }
}